import { useCallback, useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";

interface DailyIncomeEntry {
  id: string;
  date: string;
  dailyIncome: number;
  incomeMinus: number;
  totalCash: number;
  minusRegen: number;
  entryTime: string;
}

interface OTPEntry {
  id: string;
  date: string;
  otpUse: number;
  otpUseTime: string;
  otpMinus: number;
  totalOtpCash: number;
  otpMinusRegen: number;
  entryTime: string;
}

export default function StaffDashboard() {
  const [, setLocation] = useLocation();
  const [staffName, setStaffName] = useState("");
  const [selectedMonth, setSelectedMonth] = useState(
    () => new Date().toISOString().slice(0, 7) // "YYYY-MM"
  );
  const [dailyIncomeData, setDailyIncomeData] = useState<DailyIncomeEntry[]>(
    []
  );
  const [otpData, setOtpData] = useState<OTPEntry[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Redirect to login if not staff
  useEffect(() => {
    const storedUser = localStorage.getItem("staffUser");
    const userRole = localStorage.getItem("userRole");

    if (!storedUser || userRole !== "staff") {
      setLocation("/login");
      return;
    }

    setStaffName(storedUser);
  }, [setLocation]);

  // Helpers
  const getDatesForMonth = useCallback((monthStr: string) => {
    const [yearStr, monthStrNum] = monthStr.split("-");
    const year = parseInt(yearStr, 10);
    const month = parseInt(monthStrNum, 10);
    const daysInMonth = new Date(year, month, 0).getDate();
    const dates: string[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const dt = new Date(year, month - 1, d);
      dates.push(dt.toISOString().split("T")[0]); // YYYY-MM-DD
    }
    return dates;
  }, []);

  const dates = getDatesForMonth(selectedMonth);

  const storageKey = (staff: string, month: string) =>
    `staff_data::${staff}::${month}`;

  // Load saved data when staffName or month changes
  useEffect(() => {
    if (!staffName) return;
    const key = storageKey(staffName, selectedMonth);
    const raw = localStorage.getItem(key);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        setDailyIncomeData(parsed.dailyIncomeData || []);
        setOtpData(parsed.otpData || []);
      } catch {
        // ignore parse errors
      }
    } else {
      // ensure arrays are empty if no saved data
      setDailyIncomeData([]);
      setOtpData([]);
    }
  }, [staffName, selectedMonth]);

  // Daily handlers
  const handleDailyIncomeChange = (
    date: string,
    field: keyof Omit<DailyIncomeEntry, "id" | "date">,
    value: string | number
  ) => {
    const numValue = typeof value === "string" ? parseFloat(value) || 0 : value;
    const now = new Date();
    const entryTime = `${now.getHours().toString().padStart(2, "0")}:${now
      .getMinutes()
      .toString()
      .padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`;

    setDailyIncomeData((prev) => {
      const existing = prev.find((e) => e.date === date);
      if (existing) {
        const updated: DailyIncomeEntry = { ...existing, entryTime };
        if (field === "dailyIncome") updated.dailyIncome = numValue;
        if (field === "incomeMinus") updated.incomeMinus = numValue;
        if (field === "minusRegen") updated.minusRegen = numValue;
        updated.totalCash = (updated.dailyIncome || 0) - (updated.incomeMinus || 0);
        return prev.map((e) => (e.date === date ? updated : e));
      } else {
        const newEntry: DailyIncomeEntry = {
          id: `daily-${date}`,
          date,
          dailyIncome: field === "dailyIncome" ? numValue : 0,
          incomeMinus: field === "incomeMinus" ? numValue : 0,
          totalCash:
            (field === "dailyIncome" ? numValue : 0) -
            (field === "incomeMinus" ? numValue : 0),
          minusRegen: field === "minusRegen" ? numValue : 0,
          entryTime,
        };
        return [...prev, newEntry];
      }
    });
  };

  // OTP handlers
  const handleOTPChange = (
    date: string,
    field: keyof Omit<OTPEntry, "id" | "date">,
    value: string | number
  ) => {
    const numValue = typeof value === "string" ? parseFloat(value) || 0 : value;
    const now = new Date();
    const entryTime = `${now.getHours().toString().padStart(2, "0")}:${now
      .getMinutes()
      .toString()
      .padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`;

    setOtpData((prev) => {
      const existing = prev.find((e) => e.date === date);
      if (existing) {
        const updated: OTPEntry = { ...existing, entryTime };
        if (field === "otpUse") {
          updated.otpUse = numValue;
          updated.otpUseTime = entryTime;
        }
        if (field === "otpMinus") updated.otpMinus = numValue;
        if (field === "otpMinusRegen") updated.otpMinusRegen = numValue;
        updated.totalOtpCash = (updated.otpUse || 0) - (updated.otpMinus || 0);
        return prev.map((e) => (e.date === date ? updated : e));
      } else {
        const newEntry: OTPEntry = {
          id: `otp-${date}`,
          date,
          otpUse: field === "otpUse" ? numValue : 0,
          otpUseTime: field === "otpUse" ? entryTime : "",
          otpMinus: field === "otpMinus" ? numValue : 0,
          totalOtpCash:
            (field === "otpUse" ? numValue : 0) - (field === "otpMinus" ? numValue : 0),
          otpMinusRegen: field === "otpMinusRegen" ? numValue : 0,
          entryTime,
        };
        return [...prev, newEntry];
      }
    });
  };

  // Save all (persist to localStorage)
  const handleSaveAll = () => {
    const allData = {
      staffName,
      month: selectedMonth,
      dailyIncomeData,
      otpData,
      savedAt: new Date().toISOString(),
    };

    console.log("Saving data:", allData);

    // Save to localStorage for this staff + month
    try {
      const key = storageKey(staffName, selectedMonth);
      localStorage.setItem(key, JSON.stringify(allData));
    } catch (err) {
      console.error("Failed saving to localStorage", err);
    }

    // Send notification to admin (example: console/logging)
    const notification = {
      type: "data_entry",
      staffName,
      action: "Data Entry Saved",
      details: `Daily Income entries: ${dailyIncomeData.length}, OTP entries: ${otpData.length}`,
      timestamp: new Date().toISOString(),
      email: "mdronytalukder42@gmail.com",
    };

    console.log("Notification:", notification);
    alert("✅ Data saved successfully! Notification logged to console.");
  };

  const handleLogout = () => {
    localStorage.removeItem("staffUser");
    localStorage.removeItem("userRole");
    setLocation("/");
  };

  return (
    <div
      className="min-h-screen p-6 relative"
      style={{
        backgroundImage: "url(/tech-bg.jpg)",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Black Overlay */}
      <div className="absolute inset-0 bg-black/85"></div>
      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header with Logout */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Data Entry System</h1>
            <p className="text-slate-400">
              Welcome, <span className="text-blue-400 font-semibold">{staffName}</span>! Enter your daily income and OTP data.
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setLocation("/settings")}
              variant="outline"
              className="border-amber-600 text-amber-400 hover:bg-amber-900/30"
            >
              ⚙️ Settings
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-red-600 text-red-400 hover:bg-red-900/30"
            >
              Logout
            </Button>
          </div>
        </div>

        {/* Month Selector */}
        <Card className="bg-slate-800/50 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Select Month</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                {/* You can add more months dynamically if needed */}
                <SelectItem value={selectedMonth}>{selectedMonth}</SelectItem>
                <SelectItem value="2025-10">October 2025</SelectItem>
                <SelectItem value="2025-11">November 2025</SelectItem>
                <SelectItem value="2025-12">December 2025</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Daily Income Data */}
        <Card className="bg-slate-800/50 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-amber-400">Daily Income Data</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold sticky left-0 bg-slate-800/50">
                    Date
                  </th>
                  <th className="text-right py-3 px-4 text-amber-400 font-semibold">
                    Daily Income
                  </th>
                  <th className="text-right py-3 px-4 text-red-400 font-semibold">
                    Income Minus
                  </th>
                  <th className="text-right py-3 px-4 text-green-400 font-semibold">
                    Total Cash (Auto)
                  </th>
                  <th className="text-right py-3 px-4 text-slate-300 font-semibold">
                    Minus Regen
                  </th>
                  <th className="text-center py-3 px-4 text-slate-300 font-semibold">
                    Entry Time
                  </th>
                </tr>
              </thead>
              <tbody>
                {dates.map((date) => {
                  const entry = dailyIncomeData.find((e) => e.date === date);
                  return (
                    <tr
                      key={date}
                      className="border-b border-slate-700 hover:bg-slate-700/20"
                    >
                      <td className="py-3 px-4 text-slate-300 font-medium sticky left-0 bg-slate-800/50">
                        {date}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Input
                          type="number"
                          value={entry ? String(entry.dailyIncome) : ""}
                          onChange={(e) =>
                            handleDailyIncomeChange(date, "dailyIncome", e.target.value)
                          }
                          className="bg-slate-700/50 border-slate-600 text-white text-right"
                          placeholder="0"
                        />
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Input
                          type="number"
                          value={entry ? String(entry.incomeMinus) : ""}
                          onChange={(e) =>
                            handleDailyIncomeChange(date, "incomeMinus", e.target.value)
                          }
                          className="bg-slate-700/50 border-slate-600 text-white text-right"
                          placeholder="0"
                        />
                      </td>
                      <td className="py-3 px-4 text-right text-green-400 font-semibold">
                        ৳{((entry?.totalCash ?? 0)).toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Input
                          type="number"
                          value={entry ? String(entry.minusRegen) : ""}
                          onChange={(e) =>
                            handleDailyIncomeChange(date, "minusRegen", e.target.value)
                          }
                          className="bg-slate-700/50 border-slate-600 text-white text-right"
                          placeholder="0"
                        />
                      </td>
                      <td className="py-3 px-4 text-center text-slate-400 text-xs">
                        {entry?.entryTime || "-"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>

        {/* OTP System Data */}
        <Card className="bg-slate-800/50 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-blue-400">OTP System Data</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold sticky left-0 bg-slate-800/50">
                    Date
                  </th>
                  <th className="text-right py-3 px-4 text-blue-400 font-semibold">
                    OTP Use
                  </th>
                  <th className="text-center py-3 px-4 text-blue-400 font-semibold">
                    OTP Use Time
                  </th>
                  <th className="text-right py-3 px-4 text-red-400 font-semibold">
                    OTP Minus
                  </th>
                  <th className="text-right py-3 px-4 text-blue-400 font-semibold">
                    Total OTP Cash (Auto)
                  </th>
                  <th className="text-right py-3 px-4 text-slate-300 font-semibold">
                    OTP Minus Regen
                  </th>
                  <th className="text-center py-3 px-4 text-slate-300 font-semibold">
                    Entry Time
                  </th>
                </tr>
              </thead>
              <tbody>
                {dates.map((date) => {
                  const entry = otpData.find((e) => e.date === date);
                  return (
                    <tr
                      key={date}
                      className="border-b border-slate-700 hover:bg-slate-700/20"
                    >
                      <td className="py-3 px-4 text-slate-300 font-medium sticky left-0 bg-slate-800/50">
                        {date}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Input
                          type="number"
                          value={entry ? String(entry.otpUse) : ""}
                          onChange={(e) =>
                            handleOTPChange(date, "otpUse", e.target.value)
                          }
                          className="bg-slate-700/50 border-slate-600 text-white text-right"
                          placeholder="0"
                        />
                      </td>
                      <td className="py-3 px-4 text-center text-blue-400 text-xs">
                        {entry?.otpUseTime || "-"}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Input
                          type="number"
                          value={entry ? String(entry.otpMinus) : ""}
                          onChange={(e) =>
                            handleOTPChange(date, "otpMinus", e.target.value)
                          }
                          className="bg-slate-700/50 border-slate-600 text-white text-right"
                          placeholder="0"
                        />
                      </td>
                      <td className="py-3 px-4 text-right text-blue-400 font-semibold">
                        ৳{((entry?.totalOtpCash ?? 0)).toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Input
                          type="number"
                          value={entry ? String(entry.otpMinusRegen) : ""}
                          onChange={(e) =>
                            handleOTPChange(date, "otpMinusRegen", e.target.value)
                          }
                          className="bg-slate-700/50 border-slate-600 text-white text-right"
                          placeholder="0"
                        />
                      </td>
                      <td className="py-3 px-4 text-center text-slate-400 text-xs">
                        {entry?.entryTime || "-"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex gap-3 mt-4">
          <Button onClick={handleSaveAll} className="bg-emerald-600">
            Save All
          </Button>
          <Button
            onClick={() => {
              // Quick export: download JSON
              const payload = {
                staffName,
                month: selectedMonth,
                dailyIncomeData,
                otpData,
                exportedAt: new Date().toISOString(),
              };
              const blob = new Blob([JSON.stringify(payload, null, 2)], {
                type: "application/json",
              });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = `data_${staffName}_${selectedMonth}.json`;
              a.click();
              URL.revokeObjectURL(url);
            }}
            variant="outline"
            className="border-slate-600 text-slate-200"
          >
            Export JSON
          </Button>
        </div>

        <div className="mt-8 text-sm text-slate-400">
          <p>
            Tip: Data is saved to your browser localStorage per staff+month. To keep data between devices
            you can integrate an API endpoint and replace localStorage-save in handleSaveAll with a POST.
          </p>
        </div>
      </div>
    </div>
  );
}